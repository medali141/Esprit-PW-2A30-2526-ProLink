-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3308
-- Généré le : mer. 13 mai 2026 à 04:27
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `prolink`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL,
  `nom_categorie` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `nom_categorie`, `description`, `created_at`) VALUES
(1, 'Informatique', 'Formations en programmation et technologies', '2026-05-13 01:06:42'),
(2, 'Marketing', 'Formations en marketing digital', '2026-05-13 01:06:42'),
(3, 'Design', 'Formations en design graphique', '2026-05-13 01:06:42'),
(4, 'Business', 'Formations en gestion et entrepreneuriat', '2026-05-13 01:06:42');

-- --------------------------------------------------------

--
-- Structure de la table `certifications`
--

CREATE TABLE `certifications` (
  `id_certification` int(11) NOT NULL,
  `id_formation` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `niveau` varchar(50) DEFAULT 'debutant',
  `duree_heures` int(11) DEFAULT 20,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `certifications`
--

INSERT INTO `certifications` (`id_certification`, `id_formation`, `titre`, `description`, `niveau`, `duree_heures`, `actif`, `created_at`) VALUES
(1, 1, 'Certification Python', 'Certifiez vos compétences Python', 'debutant', 20, 1, '2026-05-13 01:06:42'),
(2, 1, 'Certification Marketing Digital', 'Certification reconnue en marketing digital', 'intermediaire', 15, 1, '2026-05-13 01:55:06'),
(3, 2, 'Certification Python', 'Certification officielle Python', 'debutant', 20, 1, '2026-05-13 01:55:06'),
(4, 3, 'Certification Java', 'Certification Java Oracle', 'avance', 30, 1, '2026-05-13 01:55:06');

-- --------------------------------------------------------

--
-- Structure de la table `evenement`
--

CREATE TABLE `evenement` (
  `id_event` int(11) NOT NULL,
  `titre_event` varchar(200) NOT NULL,
  `description_event` text NOT NULL,
  `type_event` varchar(100) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `lieu_event` varchar(120) NOT NULL,
  `capacite_max` int(11) NOT NULL DEFAULT 0,
  `statut` varchar(32) NOT NULL DEFAULT 'Ouvert',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `formation`
--

CREATE TABLE `formation` (
  `id_formation` int(11) NOT NULL,
  `id_categorie` int(11) DEFAULT NULL,
  `titre` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('presentiel','en_ligne') DEFAULT 'presentiel',
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `date_inscription` date DEFAULT NULL,
  `places_max` int(11) DEFAULT 30,
  `statut` varchar(50) DEFAULT 'inscrit',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `certification` varchar(255) DEFAULT NULL,
  `certification_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `formation`
--

INSERT INTO `formation` (`id_formation`, `id_categorie`, `titre`, `description`, `type`, `date_debut`, `date_fin`, `date_inscription`, `places_max`, `statut`, `created_at`, `certification`, `certification_description`) VALUES
(1, 1, 'Python pour débutants', 'Apprenez les bases de Python', 'en_ligne', '2026-06-01', '2026-06-30', NULL, 20, 'inscrit', '2026-05-13 01:06:42', NULL, NULL),
(2, 1, 'Java avancé', 'Maîtrisez Java et POO', 'presentiel', '2026-05-15', '2026-06-15', NULL, 15, 'inscrit', '2026-05-13 01:06:42', NULL, NULL),
(3, 2, 'Marketing Digital', 'SEO, réseaux sociaux, emailing', 'en_ligne', '2026-07-01', '2026-07-20', NULL, 25, 'inscrit', '2026-05-13 01:06:42', NULL, NULL),
(4, NULL, 'java', 'java', 'presentiel', '2026-05-06', '2026-05-14', NULL, 30, 'inscrit', '2026-05-13 01:07:09', NULL, NULL),
(5, 3, 'design', 'design', 'en_ligne', '2026-05-14', '2026-05-14', NULL, 30, 'inscrit', '2026-05-13 01:45:34', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

CREATE TABLE `inscription` (
  `id_inscription` int(11) NOT NULL,
  `id_formation` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `date_inscription` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`id_inscription`, `id_formation`, `nom`, `prenom`, `email`, `telephone`, `date_inscription`) VALUES
(1, 1, 'manarayari', 'manar', 'manar@gmail.com', '92580111', '2026-05-13'),
(2, 1, 'manarrrr', 'manarrrr', 'mmmm@jkj', '65165165166', '2026-05-13'),
(3, 1, 'dfgvd', 'feces', 'efce@ef', '212512541354', '2026-05-13');

-- --------------------------------------------------------

--
-- Structure de la table `participation`
--

CREATE TABLE `participation` (
  `id_participation` int(11) NOT NULL,
  `id_event` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `date_inscription` timestamp NOT NULL DEFAULT current_timestamp(),
  `statut` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `quiz_certification`
--

CREATE TABLE `quiz_certification` (
  `id_quiz` int(11) NOT NULL,
  `id_certification` int(11) NOT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `duree_minutes` int(11) DEFAULT 30,
  `seuil_reussite` int(11) DEFAULT 70
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `quiz_certification`
--

INSERT INTO `quiz_certification` (`id_quiz`, `id_certification`, `titre`, `duree_minutes`, `seuil_reussite`) VALUES
(1, 1, 'Quiz Python', 30, 70),
(2, 1, 'Quiz Marketing Digital', 30, 70),
(3, 2, 'Quiz Python', 30, 70),
(4, 3, 'Quiz Java', 30, 70);

-- --------------------------------------------------------

--
-- Structure de la table `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `id_question` int(11) NOT NULL,
  `id_quiz` int(11) NOT NULL,
  `question` text NOT NULL,
  `points` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `quiz_questions`
--

INSERT INTO `quiz_questions` (`id_question`, `id_quiz`, `question`, `points`) VALUES
(1, 1, 'Que signifie Python ?', 1),
(2, 1, 'Qui a créé Python ?', 1),
(3, 2, 'Qui a créé Python ?', 1);

-- --------------------------------------------------------

--
-- Structure de la table `quiz_reponses`
--

CREATE TABLE `quiz_reponses` (
  `id_reponse` int(11) NOT NULL,
  `id_question` int(11) NOT NULL,
  `reponse` text NOT NULL,
  `est_correcte` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `quiz_reponses`
--

INSERT INTO `quiz_reponses` (`id_reponse`, `id_question`, `reponse`, `est_correcte`) VALUES
(1, 1, 'Un langage de programmation', 1),
(2, 1, 'Un serpent', 0),
(3, 1, 'Un framework', 0),
(4, 2, 'Guido van Rossum', 1),
(5, 2, 'Linus Torvalds', 0),
(6, 2, 'Dennis Ritchie', 0),
(7, 1, 'Guido van Rossum', 1),
(8, 1, 'Linus Torvalds', 0);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `iduser` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `mdp_reset_otp_hash` varchar(255) DEFAULT NULL,
  `mdp_reset_otp_expires` datetime DEFAULT NULL,
  `type` enum('admin','candidat','entrepreneur') NOT NULL,
  `age` int(11) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`iduser`, `nom`, `prenom`, `email`, `mdp`, `mdp_reset_otp_hash`, `mdp_reset_otp_expires`, `type`, `age`, `photo`, `created_at`) VALUES
(5, 'chihaoui', 'mohammed ali', 'chihaouidali443@gmail.com', '$2y$10$legH0oYVvjIhe4ZLne4sB.c9YW8gctbNfWe5jGmRNTfPkckJp.zAe', NULL, NULL, 'admin', 75, NULL, '2026-04-15 12:30:47'),
(7, 'chihaoui', 'mohammed ali', 'chihaouidali44@gmail.com', '$2y$10$NTalhxoL.rH.uSh8sjUJlu1yhfRbg4moZpn3M3qGey03UQ8zUfmwe', NULL, NULL, 'candidat', 24, NULL, '2026-04-15 12:41:01'),
(8, 'aissa', 'idouni', 'issado@gmail.com', '$2y$10$7rT5hKUUaUBeuQUYeTkqXuVdu5nIHRn85NU9fjLAsorNAC.P3fdCy', NULL, NULL, 'candidat', 75, NULL, '2026-04-15 12:44:12'),
(9, 'ayari', 'manar', 'manarayari321@gmail.com', '$2y$10$A6DF3Va7CTSzvdZE9aHcQeEd76pVqDwp.ZTxmY4m61JOv98fb0Tye', NULL, NULL, 'admin', 21, NULL, '2026-05-13 01:10:22'),
(10, 'manar', 'manar', 'manar@gmail.com', '$2y$10$LCFrV.EVteXwf4lZLhZkreyMpLquS.Qm26QV/7u2NqHiXAZ.wlPPq', NULL, NULL, 'candidat', 21, NULL, '2026-05-13 01:13:04');

-- --------------------------------------------------------

--
-- Structure de la table `user_achievements`
--

CREATE TABLE `user_achievements` (
  `id_achievement` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_certification` int(11) NOT NULL,
  `date_obtention` date DEFAULT NULL,
  `statut` varchar(50) DEFAULT 'obtenu',
  `numero_certificat` varchar(100) DEFAULT NULL,
  `score` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user_achievements`
--

INSERT INTO `user_achievements` (`id_achievement`, `id_user`, `id_certification`, `date_obtention`, `statut`, `numero_certificat`, `score`) VALUES
(1, 9, 1, '2026-05-13', 'obtenu', 'CERT-6A03E0E590404-20260513', 100);

-- --------------------------------------------------------

--
-- Structure de la table `user_quiz_attempts`
--

CREATE TABLE `user_quiz_attempts` (
  `id_attempt` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_quiz` int(11) NOT NULL,
  `score` int(11) DEFAULT NULL,
  `statut` varchar(50) DEFAULT NULL,
  `date_tentative` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user_quiz_attempts`
--

INSERT INTO `user_quiz_attempts` (`id_attempt`, `id_user`, `id_quiz`, `score`, `statut`, `date_tentative`) VALUES
(1, 9, 1, 100, 'reussi', '2026-05-13 03:24:37');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categorie`);

--
-- Index pour la table `certifications`
--
ALTER TABLE `certifications`
  ADD PRIMARY KEY (`id_certification`),
  ADD KEY `id_formation` (`id_formation`);

--
-- Index pour la table `evenement`
--
ALTER TABLE `evenement`
  ADD PRIMARY KEY (`id_event`);

--
-- Index pour la table `formation`
--
ALTER TABLE `formation`
  ADD PRIMARY KEY (`id_formation`),
  ADD KEY `id_categorie` (`id_categorie`);

--
-- Index pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD PRIMARY KEY (`id_inscription`),
  ADD KEY `id_formation` (`id_formation`);

--
-- Index pour la table `participation`
--
ALTER TABLE `participation`
  ADD PRIMARY KEY (`id_participation`),
  ADD KEY `idx_part_event` (`id_event`);

--
-- Index pour la table `quiz_certification`
--
ALTER TABLE `quiz_certification`
  ADD PRIMARY KEY (`id_quiz`),
  ADD KEY `id_certification` (`id_certification`);

--
-- Index pour la table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`id_question`),
  ADD KEY `id_quiz` (`id_quiz`);

--
-- Index pour la table `quiz_reponses`
--
ALTER TABLE `quiz_reponses`
  ADD PRIMARY KEY (`id_reponse`),
  ADD KEY `id_question` (`id_question`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`iduser`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `user_achievements`
--
ALTER TABLE `user_achievements`
  ADD PRIMARY KEY (`id_achievement`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_certification` (`id_certification`);

--
-- Index pour la table `user_quiz_attempts`
--
ALTER TABLE `user_quiz_attempts`
  ADD PRIMARY KEY (`id_attempt`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_quiz` (`id_quiz`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id_categorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `certifications`
--
ALTER TABLE `certifications`
  MODIFY `id_certification` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `evenement`
--
ALTER TABLE `evenement`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `formation`
--
ALTER TABLE `formation`
  MODIFY `id_formation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `inscription`
--
ALTER TABLE `inscription`
  MODIFY `id_inscription` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `participation`
--
ALTER TABLE `participation`
  MODIFY `id_participation` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `quiz_certification`
--
ALTER TABLE `quiz_certification`
  MODIFY `id_quiz` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  MODIFY `id_question` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `quiz_reponses`
--
ALTER TABLE `quiz_reponses`
  MODIFY `id_reponse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `user_achievements`
--
ALTER TABLE `user_achievements`
  MODIFY `id_achievement` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `user_quiz_attempts`
--
ALTER TABLE `user_quiz_attempts`
  MODIFY `id_attempt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `certifications`
--
ALTER TABLE `certifications`
  ADD CONSTRAINT `fk_certifications_formation` FOREIGN KEY (`id_formation`) REFERENCES `formation` (`id_formation`) ON DELETE CASCADE;

--
-- Contraintes pour la table `formation`
--
ALTER TABLE `formation`
  ADD CONSTRAINT `fk_formation_categorie` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id_categorie`) ON DELETE SET NULL;

--
-- Contraintes pour la table `participation`
--
ALTER TABLE `participation`
  ADD CONSTRAINT `fk_part_evenement` FOREIGN KEY (`id_event`) REFERENCES `evenement` (`id_event`) ON DELETE CASCADE;

--
-- Contraintes pour la table `quiz_certification`
--
ALTER TABLE `quiz_certification`
  ADD CONSTRAINT `fk_quiz_certification` FOREIGN KEY (`id_certification`) REFERENCES `certifications` (`id_certification`) ON DELETE CASCADE;

--
-- Contraintes pour la table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD CONSTRAINT `fk_quiz_questions` FOREIGN KEY (`id_quiz`) REFERENCES `quiz_certification` (`id_quiz`) ON DELETE CASCADE;

--
-- Contraintes pour la table `quiz_reponses`
--
ALTER TABLE `quiz_reponses`
  ADD CONSTRAINT `fk_quiz_reponses` FOREIGN KEY (`id_question`) REFERENCES `quiz_questions` (`id_question`) ON DELETE CASCADE;

--
-- Contraintes pour la table `user_achievements`
--
ALTER TABLE `user_achievements`
  ADD CONSTRAINT `fk_achievements_certif` FOREIGN KEY (`id_certification`) REFERENCES `certifications` (`id_certification`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_achievements_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`iduser`) ON DELETE CASCADE;

--
-- Contraintes pour la table `user_quiz_attempts`
--
ALTER TABLE `user_quiz_attempts`
  ADD CONSTRAINT `fk_attempts_quiz` FOREIGN KEY (`id_quiz`) REFERENCES `quiz_certification` (`id_quiz`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_attempts_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`iduser`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
